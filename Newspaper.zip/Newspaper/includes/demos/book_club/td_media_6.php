<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_logo_footer',             'http://demo_content.tagdiv.com/Newspaper_6/book_club/footer-logo.png');
td_demo_media::add_image_to_media_gallery('td_logo_footer_retina',      'http://demo_content.tagdiv.com/Newspaper_6/book_club/footer-logo@2x.png');

//ads
td_demo_media::add_image_to_media_gallery('td_rec_sidebar',              "http://demo_content.tagdiv.com/Newspaper_6/book_club/rec-sidebar.png");

