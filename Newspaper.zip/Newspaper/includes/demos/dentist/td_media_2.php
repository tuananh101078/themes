<?php

// featured images
td_demo_media::add_image_to_media_gallery('td_pic_7',                    "http://demo_content.tagdiv.com/Newspaper_multi/dentist/7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_8',                    "http://demo_content.tagdiv.com/Newspaper_multi/dentist/8.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_9',                    "http://demo_content.tagdiv.com/Newspaper_multi/dentist/9.jpg");

// post photos
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_multi/dentist/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newspaper_multi/dentist/p2.jpg");

//logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_multi/dentist/logo-header.png");
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             "http://demo_content.tagdiv.com/Newspaper_multi/dentist/logo-mobile.png");

