<?php

// featured images
td_demo_media::add_image_to_media_gallery('td_pic_5',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_architecture/5.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_6',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_architecture/6.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_7',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_architecture/7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_8',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_architecture/8.jpg");