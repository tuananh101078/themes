<?php
//ads
td_demo_media::add_image_to_media_gallery('td_animals_header_ad',               "http://demo_content.tagdiv.com/Newspaper_6/animals/banner-header.png");
td_demo_media::add_image_to_media_gallery('td_animals_post_ad',                 "http://demo_content.tagdiv.com/Newspaper_6/animals/banner-post.jpg");
td_demo_media::add_image_to_media_gallery('td_animals_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/animals/banner-sidebar.jpg");
